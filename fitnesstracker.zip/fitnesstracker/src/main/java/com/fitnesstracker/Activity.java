package com.fitnesstracker;

public class Activity {
    private int id;
    @SuppressWarnings("unused")
	private String activityName;
    @SuppressWarnings("unused")
	private int duration;
    @SuppressWarnings("unused")
	private int caloriesBurned;
    @SuppressWarnings("unused")
	private String date;
	public void setActivityName(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setDuration(int int1) {
		// TODO Auto-generated method stub
		
	}
	public void setId(int int1) {
		// TODO Auto-generated method stub
		
	}
	public void setCaloriesBurned(int int1) {
		// TODO Auto-generated method stub
		
	}
	public void setDate(String string) {
		// TODO Auto-generated method stub
		
	}

    // Getters and Setters
}